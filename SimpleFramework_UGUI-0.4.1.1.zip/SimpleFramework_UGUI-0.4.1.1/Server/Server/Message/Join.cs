﻿using System;
using SimpleFramework.Common;

namespace SimpleFramework.Message {
    class Join :IMessage {
        public void OnMessage(ClientSession session, ByteBuffer buffer) {
        }
    }
}
