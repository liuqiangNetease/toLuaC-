using System;
using System.Collections;

namespace SimpleFramework.Manager {
    public interface ITimerBehaviour {
        void TimerUpdate();
    }
}