﻿using System;

public class NoToLuaAttribute : System.Attribute
{
    public NoToLuaAttribute()
    {

    }
}

public class OnlyGCAttribute : System.Attribute
{
    public OnlyGCAttribute()
    {

    }
}

public class UseDefinedAttribute : System.Attribute
{
    public UseDefinedAttribute()
    {

    }
}