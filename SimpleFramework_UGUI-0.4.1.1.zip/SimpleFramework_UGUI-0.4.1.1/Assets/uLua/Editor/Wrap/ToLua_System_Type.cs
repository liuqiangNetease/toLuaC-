﻿using UnityEngine;
using System.Collections;

public class ToLua_System_Type
{

}
