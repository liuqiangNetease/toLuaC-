﻿using UnityEngine;
using System;
using System.Collections;
using LuaInterface;

public static class TestProtol
{
    public static LuaStringBuffer data; 
}
